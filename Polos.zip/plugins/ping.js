module.exports = {
  name: 'ping',
  aliases: ['p'],
  command: ['ping', 'p'],
  help: ['ping', 'p'],
  tags: ['info'],

  async run({ reply, m, config, Frogzz }) {
    const sentAt = Date.now()
    const messageAt = m.messageTimestamp ? Number(m.messageTimestamp) * 1000 : sentAt
    const messageLatency = Math.max(0, sentAt - messageAt)

    await reply([
      '╭─「 PONG 」',
      `│ Response : ${Date.now() - sentAt} ms`,
      `│ Message  : ${messageLatency} ms`,
      `│ Status   : ${Frogzz?.user ? 'Connected' : 'Connecting'}`,
      `│ Bot      : ${config.botName}`,
      '╰────────────'
    ].join('\n'))
  }
}
